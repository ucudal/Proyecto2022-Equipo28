﻿using System;  
namespace factoriales;
class Program
{
    static void Main()
    {
        int n = 5;
        int a = n;
        for (int b = 1; b == a; b++)
        {
            n = n * b;
        }
        Console.WriteLine("0",n);
    }
}