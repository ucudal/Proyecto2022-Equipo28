﻿namespace Library;

public class Administrador
{
     public void Ofertas()
    {
        //dar de baja ofertas de servicios, avisando al oferente para que de esa forma, pueda evitar ofertas inadecudas.
    }
    public void Categorías()
    {
        //indicar categorías sobre las cuales se realizarán las ofertas de servicios para que de esa forma, los trabajadoras puedan clasificarlos.
    }
    

}









